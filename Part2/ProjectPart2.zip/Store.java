import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.BufferedReader;

class Store {
		
	public static void main(String[] args) throws FileNotFoundException, IOException
	{
	Movies inventory = new Movies();
	Scanner in = new Scanner(System.in);
	char input;
	char response;
		do{
			
			System.out.println("Select an Option");
			System.out.println("C. CashRegister I. Inventory Management E. Employee Management R. Reports Q. Quit");
		
			
			input = in.next().toLowerCase().charAt(0);
			if(input == 'i')
				
			{
			inventory.usemovielist();
			  inventory.menu();
				
			}
			else if(input == 'c')
			{
				System.out.println("Cash Register selected");
            	CashRegister register1 = new CashRegister();
            	register1.cashMenu();
			}
			else if (input == 'e')
			{
				System.out.println("Employee management selected");
				Employee employee1 = new Employee();
				employee1.useemplist();
            	employee1.menu();
			}
			else if (input == 'r')
			{
				InventoryReport report1 = new InventoryReport();	
				EmployeeReport report2 = new EmployeeReport();
				System.out.println("Would you like to view the i-inventory report, e-employee report,");
				System.out.println("n-number of inventory, c- count employees?");
				response = in.next().toLowerCase().charAt(0);
				if(response == 'i')
				{
				report1.printmovielist();
				}
				
				else if(response == 'e')
				{
				report1.printemployeelist();
				}
				else if(response == 'n')
				{
				report1.countinventory();
				}
				else if(response == 'c')
				{	
				report2.countemps();
				}
			}
			else if (input == 'q')
			{
				break;
			}
			else
			{
				System.out.println("Invalid input");
			}
		}while (input != 'q');
	}
}
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Report {
	

	public void printmovielist() throws FileNotFoundException {

	String name = "movielist.txt";
	File file = new File(name);
	Scanner scan = new Scanner(file);
	
	while(scan.hasNextLine()){
	System.out.println(scan.nextLine());
	}
	}
	
	public void printemployeelist() throws FileNotFoundException {

	String name = "employeelist.txt";
	File file = new File(name);
	Scanner scan = new Scanner(file);
	
	while(scan.hasNextLine()){
	System.out.println(scan.nextLine());
	}
	}
}
import java.io.File;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileReader;


public class Movies{
	//creates Map that stores a String key and String value
	private Map<String, String> inventory = new HashMap<String, String>();
	String value;

	public void usemovielist() throws IOException{
		
	String filePath = "movielist.txt";
	String line;
	BufferedReader reader = new BufferedReader(new FileReader(filePath));
    while ((line = reader.readLine()) != null)
    {
        String[] parts = line.split(":", 2);
        if (parts.length >= 2)
        {
            String key = parts[0];
            String value = parts[1];
            inventory.put(key, value);
        } else {
            System.out.println("ignoring line: " + line);
        }
    }
	System.out.println("CURRENT INVENTORY LIST-");
    for (String key : inventory.keySet())
    {
		
        System.out.println(key + ":" + inventory.get(key));
    }
    reader.close();
		
	}



	//menu method that the user inputs change the grades Map
	public void menu() throws IOException {
	//Gets input from user after printing options
	Scanner myObj = new Scanner(System.in);
	System.out.println("");
	System.out.println("Inventory List-You can Add, Modify, or Print Inventory!");
	System.out.println("A-Add, M-Modify, R-Remove,P-Print, or Q-Quit");
	System.out.println("Select an option");

	
	String option = myObj.nextLine();
	//while loop to keep menu running until q is selected	
	while (!option.equals("q")) 
	{
		//if option is A or a then will add for name and category to add to Hashmap
	
		if (option.equals("a") ||
			option.equals("A"))
		{	
		System.out.println("What is the Movie name?");
		String name = myObj.nextLine();
		System.out.println("What is the Movie category");
		String category = myObj.nextLine();
		inventory.put(name, category);
		}
		//if option is r or R then will remove name and category from Hashmap
		else if (option.equals("r") ||
			option.equals("R"))
		{	
		remove();
		}
		// if option m or M then will add a Student and category overriding the original
		else if (option.equals("m") ||
			option.equals("M"))
		{	
		System.out.println("What is the Movie name?");
		String name = myObj.nextLine();
		System.out.println("What is the Movie category?");
		String category = myObj.nextLine();
		inventory.put(name, category);
		}
		//Print
		else if (option.equals("p") ||
			option.equals("P"))
		{
		print();
		}
		else if (option.equals("s") ||
			option.equals("s"))
		{
		save();
		}
		//gives message for invalid option selected
		else
		{
		System.out.println("invalid");

		}
		//gets new input to continue while loop until q is selected
		System.out.println("Select an option");
		option = myObj.nextLine();
		}	
	
	}
	public void add() {
		
		
	}
	public void remove(){
		
	Scanner scan = new Scanner(System.in);	
	System.out.println("What is the Movie name?");
	String name = scan.nextLine();
	inventory.remove(name);
	}

	public void print() {
		{	

		for (String name : inventory.keySet())
				{
					System.out.println(name + ": " + inventory.get(name));
				}
		}
		
	}
	public void save() throws IOException {

    String outputFilePath = "movielist.txt";
 

        
        //new file object
        File file = new File(outputFilePath);
        
        BufferedWriter bf = null;;
        
        try{
            
            //create new BufferedWriter for the output file
            bf = new BufferedWriter( new FileWriter(file, false) );
 
            //iterate map entries
            for(Map.Entry<String, String> entry : inventory.entrySet()){
                
                //put key and value separated by a colon
                bf.write( entry.getKey() + ":" + entry.getValue() );
                
                //new line
                bf.newLine();
            }
            
            bf.flush();
 
        }catch(IOException e){
            e.printStackTrace();
        }finally{
            
            try{
                //always close the writer
                bf.close();
            }catch(Exception e){}
			}
	}

}
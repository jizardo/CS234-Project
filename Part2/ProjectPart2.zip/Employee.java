import java.util.Scanner;
import java.io.File;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileReader;

import java.util.HashMap;
import java.util.Scanner;
public class Employee {
	private String name;
	private String id;
	private HashMap<String, String> listOfEmployees = new HashMap<String, String>();
	
	public Employee() throws IOException {

	}
	public void useemplist() throws IOException{
		
	String filePath = "employeelist.txt";
	String line;
	BufferedReader reader = new BufferedReader(new FileReader(filePath));
    while ((line = reader.readLine()) != null)
    {
        String[] parts = line.split(":", 2);
        if (parts.length >= 2)
        {
            String key = parts[0];
            String value = parts[1];
            listOfEmployees.put(key, value);
        } else {
            System.out.println(line);
        }
    }
	System.out.println("CURRENT EMPLOYEE LIST-");
    for (String key : listOfEmployees.keySet())
    {
		
        System.out.println(key + ":" + listOfEmployees.get(key));
    }
    reader.close();
		
	}


	public void menu()
	{
		Scanner in = new Scanner(System.in);
		boolean done = false;
		while(!done)
		{
			System.out.println("A)dd R)emove E)dit Q)uit S)ave");

			String input = in.next().toUpperCase();
			
			if(input.equals("Q"))
			{
				done = true;
			}
			
			else if(input.equals("A"))
			{
				System.out.print("Enter the employee's name: ");
				String name = in.next();
				System.out.print("Enter the employee's id: ");
				String id = in.next();
				listOfEmployees.put(name, id);
			}
			
			else if(input.equals("R"))
			{
				System.out.print("Enter the employee's name: ");
				String name = in.next();
				listOfEmployees.remove(name);
			}
			
			else if(input.equals("E"))
			{
				System.out.print("Enter the employee's name: ");
				String name = in.next();
				System.out.print("Enter the employee's id: ");
				String id = in.next();
				listOfEmployees.put(name, id);
			}
			
			else if(input.equals("P"))
			{
				System.out.println(name);
				System.out.println(id);
			}
			else if(input.equals("S"))
			{
			
			String outputFilePath = "employeelist.txt";

			File file = new File(outputFilePath);
			
			BufferedWriter bf = null;;
			
			try{
				
				//create new BufferedWriter for the output file
				bf = new BufferedWriter( new FileWriter(file, false) );
	 
				//iterate map entries
				for(Map.Entry<String, String> entry : listOfEmployees.entrySet()){
					
					//put key and value separated by a colon
					bf.write( entry.getKey() + ":" + entry.getValue() );
					
					//new line
					bf.newLine();
				}
				
				bf.flush();
	 
				}catch(IOException e){
					e.printStackTrace();
				}finally{
					
					try{
						//always close the writer
						bf.close();
					}catch(Exception e){}
					}
					}
					
					else
					{
						System.out.println("Not a valid option.");
					}
			
		}	
	}
}

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.io.FileWriter;
import java.io.IOException;
/**
 * Isaac Evans
 * Part 2 Project
 * Cash Register
 */
public class CashRegister
{
    private int movieCount;
    private double totalPrice;
    double price;
    Movies inventory = new Movies();/*******/
    Scanner myObj = new Scanner(System.in);
    
    public void cashMenu() throws IOException
    {
        Scanner myObj = new Scanner(System.in);
        System.out.println("Cash Register-You can Add, Remove, Get total, and checkout a movie from pricing!");
        System.out.println("A-Add, R-Remove,T-Total, C-Checkout or Q-Quit");
        System.out.println("Select an option");

    
        char option = myObj.next().toLowerCase().charAt(0);
        //while loop to keep menu running until q is selected    
        while (option != 'q') 
        {
        //if option is A it will add movie to the cash Register
    
        if (option == 'a')
        {  
           addMovie();
        }
        //if option is r or R then will remove name and category from Hashmap
        else if (option == 'r')
        {   
            removeMovie();
        }
        //Print the total
        else if (option == 't')
        {    
            System.out.println("this is the total: " + getTotal());
            System.out.println("This is the movieCount " + movieCount);

        }
        else if(option == 'c')
        {
            checkout();
            break;
        }
        //gets new input to continue while loop until q is selected        
        System.out.println("Cash Register-You can Add, Remove, Get total, and checkout a movie from pricing!");
        System.out.println("A-Add, R-Remove,T-Total, C-Checkout or Q-Quit");
        System.out.println("Select an option");

    
        option = myObj.next().toLowerCase().charAt(0);
        }
        }
    /**
     * Constructor a cash Register with cleared item count and total
     */
    public CashRegister()
    {
        // initialise instance variables
        movieCount = 0;
        price = 2.99;
        totalPrice = 0;
    }
    
    
    //Adds the movie to the CashRegister
    public void addMovie()
    {
        System.out.println("You have added a movie that is: " + price);
        movieCount++;
        totalPrice = totalPrice + price;
    }
    
    //Removes the movie from the Cash Register
    public void removeMovie()
    {
        movieCount--;
        totalPrice = totalPrice - price;
        inventory.remove();
        System.out.println("You have removed a movie");
    }
    
    
    //Gets the total cost of movies
    public double getTotal()
    {
        return totalPrice;
    }
    
    
    //verifying that the payment was made
    
    public void checkout() throws IOException {
    
    File file = new File("movielist.txt");
    Scanner scan = new Scanner(file);
    
    String fileContent = "New Movie";
    
    while(scan.hasNextLine()) {
        fileContent = fileContent.concat(scan.nextLine() + "\n");
    }
    FileWriter writer = new FileWriter("newmovielist.txt");
    writer.write(fileContent);
    writer.close();
    System.out.println("Saved");
    
    System.out.println("You have made your purchase, thank you!");
        movieCount = 0;
        totalPrice = 0;
    }
}
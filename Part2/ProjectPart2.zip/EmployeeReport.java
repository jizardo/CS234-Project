import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class EmployeeReport extends Report {
	
  int count = 0;
	public void countemps(){
		try {
		  // create a new file object
		  File file = new File("employeelist.txt");

		  // create an object of Scanner
		  // associated with the file
		  Scanner sc = new Scanner(file);

		  // read each line and
		  // count number of lines
		  while(sc.hasNextLine()) {
			sc.nextLine();
			count++;
		  }
		  System.out.println("Total Number of Employees: " + count);

		  // close scanner
		  sc.close();
		} catch (Exception e) {
		  e.getStackTrace();
		}
	}
 
}


import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

    public class InvReport<lines> {
        public String name;
        public int id;
        public String title;
        public String category;

        public long getcount() {
            Path path = Paths.get("movies.txt");
            long lines = 0;
            try {
                lines = Files.lines(path).count();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return lines;
        }
    }

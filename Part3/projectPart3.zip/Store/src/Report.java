import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

    public class Report<lines> {
        public long getcount() {
            Path path = Paths.get("employeedata.txt");
            long lines = 0;
            try {
                lines = Files.lines(path).count();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return lines;
        }

    }



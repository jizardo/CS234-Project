import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;


public class CashSwing extends JFrame{
    private JButton addButton, removeButton, totalButton, Quit;
    private JTextField textField1;
    private JTextArea textArea1;
    private JPanel parentPanel;

    //cashRegister variables
    private int movieCount;
    private double totalPrice;
    double price;
    //Movies inventory = new Movies();/*******/
    Scanner myObj = new Scanner(System.in);





    public CashSwing()
    {
        movieCount = 0;
        price = 2.99;
        totalPrice = 0;

        // Define the size of the frame
        this.setSize(400, 400);

        // Toolkit is the super class for the Abstract Window Toolkit
        // It allows us to ask questions of the OS

        Toolkit tk = Toolkit.getDefaultToolkit();

        // A Dimension can hold the width and height of a component
        // getScreenSize returns the size of the screen

        Dimension dim = tk.getScreenSize();

        int xPos = (dim.width / 2) - (this.getWidth() / 2);
        int yPos = (dim.height / 2) - (this.getHeight() / 2);

        this.setLocation(xPos, yPos);

        //this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        this.setTitle("Cash Register");

        JPanel thePanel = new JPanel();


        JLabel label1 = new JLabel("Cash Register");

        label1.setToolTipText("Name"); //Hover mouse over "New Text"

        thePanel.add(label1);



        //BUTTONS----------------------------

        JButton addButton = new JButton("Add");
        JButton removeButton = new JButton("Remove");
        JButton totalButton = new JButton("Total");
        JButton quitButton = new JButton("Quit");



        //adds the button to the panel
        thePanel.add(addButton);
        thePanel.add(removeButton);
        thePanel.add(totalButton);
        thePanel.add(quitButton);

        //--------------------------------------



        //How to add a text field------------------
        //textField1 = new JTextField("Type here",7);

        //thePanel.add(textField1);

        addButton.setToolTipText("This is a button");

        //JTextField textField1 = new JTextField("Type here", 15);

        //textField1.setColumns(10);

        //How to add a text Area-------------------


        JTextArea textArea1 = new JTextArea(15, 30);

        textArea1.setText("");


        thePanel.add(textArea1);

        // If text doesn't fit on a line, jump to the next

        textArea1.setLineWrap(true);

        // Makes sure that words stay intact if a line wrap occurs

        textArea1.setWrapStyleWord(true);

        // Adds scroll bars to the text area ----------

        JScrollPane scrollBar1 = new JScrollPane(textArea1, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);

        // Other options: VERTICAL_SCROLLBAR_ALWAYS, VERTICAL_SCROLLBAR_NEVER

        thePanel.add(scrollBar1);

        this.add(thePanel);

        this.setVisible(true);

        //-------------------------------------------------------
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //Adds the movie to the CashRegister
                //JOptionPane.showMessageDialog(thePanel.getComponent(0), "Hello World");
                movieCount++;
                totalPrice = totalPrice + price;
                textArea1.append("You have added a movie that is: " + price + "\n");

            }
        });
        removeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //Removes the movie from the Cash Register
                movieCount--;
                totalPrice = totalPrice - price;
                //inventory.remove();
                textArea1.append("You have removed a movie" + "\n");

            }
        });
        totalButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                //Gets the total cost of movies
                textArea1.append("Your total is " + totalPrice + "" +
                        "\n");

            }
        });
        quitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                textArea1.setText("Thank you for your purchase!");

            }
        });

    }

}
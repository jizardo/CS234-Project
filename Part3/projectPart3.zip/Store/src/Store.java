import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.io.*;
import java.util.Scanner;

public class Store {
    private JPanel Store;
    private JPanel buttonPanel;
    private JPanel titlePanel;
    private JPanel lbuttonPanel;
    private JPanel rbuttonPanel;
    private JPanel parentPanel;
    private JButton registerButton;
    private JButton empButton;
    private JButton invButton;
    private JButton reportButton;
    private JPanel registerPanel;
    private JPanel invPanel;
    private JPanel empPanel;
    private JPanel reportPanel;
    private JTextArea moviestextArea2;
    private JButton saveButton;
    private JButton refreshButton;
    private JTextArea EmployeeListArea1;
    private JButton saveButton2;
    private JButton refreshButton2;
    private JButton emprptButton;
    private JButton invrptButton;
    private JTextArea reportTextArea;
    private JButton searchbutton;
    private JTextField searchTextField;
    private JTextArea searchTextArea;

    public Store() {
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            parentPanel.removeAll();
            parentPanel.add(registerPanel);
            parentPanel.repaint();
            parentPanel.revalidate();
            CashSwing register = new CashSwing();
            registerPanel.add(register);
            }
        });
        invButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                parentPanel.removeAll();
                parentPanel.add(invPanel);
                parentPanel.repaint();
                parentPanel.revalidate();
            }
        });
        empButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                parentPanel.removeAll();
                parentPanel.add(empPanel);
                parentPanel.repaint();
                parentPanel.revalidate();
            }
        });
        reportButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                parentPanel.removeAll();
                parentPanel.add(reportPanel);
                parentPanel.repaint();
                parentPanel.revalidate();
            }
        });
        moviestextArea2.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                super.componentResized(e);
                String filePath = "movies.txt";
                try {
                    FileReader readerm = new FileReader(filePath);
                    BufferedReader brm = new BufferedReader(readerm);
                    moviestextArea2.read(brm, null);
                    brm.close();
                } catch (FileNotFoundException ex) {
                    ex.printStackTrace();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) { writeTextFile(moviestextArea2, "movies.txt"); }
        });
        refreshButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String filePath = "movies.txt";
                try {
                    FileReader readerm = new FileReader(filePath);
                    BufferedReader brm = new BufferedReader(readerm);
                    moviestextArea2.read(brm, null);
                    brm.close();
                } catch (FileNotFoundException ex) {
                    ex.printStackTrace();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }

        });
        EmployeeListArea1.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                super.componentResized(e);

                    String filePath = "employeedata.txt";
                    try {
                        FileReader readerm = new FileReader(filePath);
                        BufferedReader brm = new BufferedReader(readerm);
                        EmployeeListArea1.read(brm, null);
                        brm.close();
                    } catch (FileNotFoundException ex) {
                        ex.printStackTrace();
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                }
        });
        saveButton2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                writeTextFile(EmployeeListArea1, "employeedata.txt");
            }
        });
        refreshButton2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String filePath = "employeedata.txt";
                try {
                    FileReader readerm = new FileReader(filePath);
                    BufferedReader brm = new BufferedReader(readerm);
                    EmployeeListArea1.read(brm, null);
                    brm.close();
                } catch (FileNotFoundException ex) {
                    ex.printStackTrace();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });

        reportTextArea.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                super.componentResized(e);
            }
        });
        invrptButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                reportTextArea.setText("");
                InvReport inv = new InvReport();
                long number = inv.getcount();
                reportTextArea.append("This is the number of movies " + number);
            }
        });
        moviestextArea2.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                super.componentResized(e);
            }
        });
        emprptButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                reportTextArea.setText("");
                Report emp = new Report();
                long number = emp.getcount();
                reportTextArea.append("This is the number of employees " + number);
            }
        });
       searchbutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            String search = searchTextField.getText();
            searchTextArea.append("You searched for " + search);
            }
        });
 /*               String filename = "movies.txt";


                Scanner scan = new Scanner(new File(filename));
                while(scan.hasNext()){
                    String line = scan.nextLine().toLowerCase().toString();
                    if(line.contains(searchTextField.getText())) {
                        System.out.print(line);
                    }
                }
 //           }

        });
 */
        searchTextField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
    } //end contstructor

    private void writeTextFile(JTextArea textArea, String fileName) {
        try {
            FileWriter outStream2 = new FileWriter(fileName);
            outStream2.write(textArea.getText());
            outStream2.close();
        } catch(IOException e) {
            textArea.setText("IOError" + e.getMessage() + "\n");
            e.printStackTrace();
        }
    }
    public static void main(String[] args) {
        JFrame frame = new JFrame("Store");
        frame.setContentPane(new Store().Store);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
